/* 17173 CMS 厂商稿发布助手 - Chrome 扩展 content script (world: MAIN) */
(function () {
  'use strict';

  var $ = window.$ || null;
  var W = window;

  var CFG = {
    CATEGORY_NAME: '厂商合作供稿',
    SOURCE_TEXT: '厂商稿',
    TITLE_MAX_LEN: 50,
    IMG_SIZE_THRESHOLD: 1.5 * 1024 * 1024,
    IMG_MAX_EDGE: 1920,
    IMG_JPEG_QUALITY: 0.85,
    UPLOAD_TIMEOUT: 120000
  };

  var state = {
    docxFile: null,
    parsedHtml: '',
    images: [],
    running: false,
    autoUpload: true,
    compress: true,
    stripDup: true,
    docTitle: ''
  };

  var logBox = null;

  /* ================= 工具 ================= */
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function log(msg, cls) {
    cls = cls || '';
    try { console.log('[CMS助手] ' + msg); } catch (e) { }
    if (!logBox) return;
    var div = document.createElement('div');
    div.textContent = '[' + new Date().toLocaleTimeString() + '] ' + msg;
    div.style.color = cls === 'err' ? '#c62828' : cls === 'ok' ? '#2e7d32' : cls === 'warn' ? '#e65100' : '#333';
    logBox.appendChild(div);
    logBox.scrollTop = logBox.scrollHeight;
  }

  function waitFor(checkFn, timeout, interval, desc) {
    interval = interval || 300;
    var start = Date.now();
    return new Promise(function (resolve, reject) {
      (function tick() {
        var v;
        try { v = checkFn(); } catch (e) { }
        if (v) return resolve(v);
        if (Date.now() - start > timeout) return reject(new Error('等待超时: ' + (desc || 'unknown')));
        setTimeout(tick, interval);
      })();
    });
  }

  function clickEl(el) {
    if (!el) return;
    ['mousedown', 'mouseup', 'click'].forEach(function (type) {
      try { el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window })); } catch (e) { }
    });
  }
  function realClick(el) {
    if (!el) return;
    try { el.click(); } catch (e) { }
    clickEl(el);
  }
  function isVisible(el) {
    if (!el) return false;
    var rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    var s = window.getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function simulateInput($input, text) {
    if (!$input || !$input.length) return;
    $input.val(text);
    try { $input[0].dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { }
    try { $input[0].dispatchEvent(new Event('change', { bubbles: true })); } catch (e) { }
    try { $input.trigger('input').trigger('change').trigger('keyup'); } catch (e) { }
  }
  function findInput(candidates) {
    if (!$) return { $el: null, hit: null };
    for (var i = 0; i < candidates.length; i++) {
      var $el = $(candidates[i]).first();
      if ($el.length && $el.is(':visible')) return { $el: $el, hit: candidates[i] };
    }
    return { $el: null, hit: null };
  }

  /* ================= 轻量 DOCX 解析：识别文内标题（加粗/大字） ================= */

  async function readZipEntry(arrayBuffer, entryName) {
    var dv = new DataView(arrayBuffer);
    var byteLen = arrayBuffer.byteLength;
    var eocd = -1;
    for (var i = byteLen - 22; i >= Math.max(0, byteLen - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('无效 DOCX');
    var total = dv.getUint16(eocd + 10, true);
    var pos = dv.getUint32(eocd + 16, true);
    for (var n = 0; n < total; n++) {
      if (dv.getUint32(pos, true) !== 0x02014b50) break;
      var method = dv.getUint16(pos + 10, true);
      var compSize = dv.getUint32(pos + 20, true);
      var nameLen = dv.getUint16(pos + 28, true);
      var extraLen = dv.getUint16(pos + 30, true);
      var commentLen = dv.getUint16(pos + 32, true);
      var localOffset = dv.getUint32(pos + 42, true);
      var name = new TextDecoder('utf-8').decode(new Uint8Array(arrayBuffer, pos + 46, nameLen));
      if (name === entryName) {
        var nl = dv.getUint16(localOffset + 26, true);
        var el = dv.getUint16(localOffset + 28, true);
        var start = localOffset + 30 + nl + el;
        var raw = new Uint8Array(arrayBuffer, start, compSize);
        if (method === 0) return raw;
        if (method === 8) {
          var ds = new DecompressionStream('deflate-raw');
          var stream = new Blob([raw]).stream().pipeThrough(ds);
          return new Uint8Array(await new Response(stream).arrayBuffer());
        }
        return null;
      }
      pos += 46 + nameLen + extraLen + commentLen;
    }
    return null;
  }

  async function extractTitleFromDocx(file) {
    var ab = await file.arrayBuffer();
    var raw = await readZipEntry(ab, 'word/document.xml');
    if (!raw) throw new Error('docx 缺少 word/document.xml');
    var xml = new TextDecoder('utf-8').decode(raw);
    var doc = new DOMParser().parseFromString(xml, 'application/xml');

    var paras = Array.prototype.slice.call(doc.getElementsByTagName('w:p'));
    var list = [];
    for (var i = 0; i < paras.length; i++) {
      var text = '';
      var bold = false, maxSize = 0;
      var ts = paras[i].getElementsByTagName('w:t');
      for (var a = 0; a < ts.length; a++) text += (ts[a].textContent || '');
      var runs = paras[i].getElementsByTagName('w:r');
      for (var b = 0; b < runs.length; b++) {
        var rprs = runs[b].getElementsByTagName('w:rPr');
        if (!rprs.length) continue;
        if (rprs[0].getElementsByTagName('w:b').length) bold = true;
        var szs = rprs[0].getElementsByTagName('w:sz');
        if (szs.length) {
          var v = parseInt(szs[0].getAttribute('w:val') || szs[0].getAttribute('val') || '0', 10);
          if (v > maxSize) maxSize = v;
        }
      }
      text = (text || '').replace(/\s+/g, ' ').trim();
      if (text) list.push({ text: text, bold: bold, maxSize: maxSize });
    }

    for (var j = 0; j < list.length; j++) {
      if (list[j].bold && list[j].text) return list[j].text.slice(0, CFG.TITLE_MAX_LEN);
    }
    var maxS = 0;
    for (var k = 0; k < list.length; k++) if (list[k].maxSize > maxS) maxS = list[k].maxSize;
    if (maxS > 0) {
      for (var m = 0; m < list.length; m++) {
        if (list[m].maxSize === maxS && list[m].text) return list[m].text.slice(0, CFG.TITLE_MAX_LEN);
      }
    }
    if (list.length) return list[0].text.slice(0, CFG.TITLE_MAX_LEN);
    return '';
  }

  /* ================= 步骤1 分类选择 ================= */
  async function selectCategory() {
    log('▶ 步骤1/6: 选择分类「' + CFG.CATEGORY_NAME + '」', 'info');
    if (!$) throw new Error('页面未加载 jQuery');
    var $box = $('[data-role="selectedBox"]').first();
    if ($box.length && ($box.text() || '').indexOf(CFG.CATEGORY_NAME) >= 0) {
      log('分类已存在，跳过。', 'ok');
      return;
    }
    var $moreBtn = $('button[data-role="selectCategory"]').first();
    if (!$moreBtn.length) throw new Error('未找到"更多分类"按钮');
    $moreBtn.trigger('click');

    await waitFor(function () {
      return $('input[data-role="input"][placeholder*="搜索分类"]').length > 0 ? true : null;
    }, 10000, 200, '分类搜索框');
    await waitFor(function () { return $('#J_AllTree li').length > 0 ? true : null; }, 10000, 300, 'ztree 节点');

    var $searchInput = $('input[data-role="input"][placeholder*="搜索分类"]').first();
    simulateInput($searchInput, CFG.CATEGORY_NAME);
    await sleep(1000);

    var $targetLi = await waitFor(function () {
      var hit = null;
      $('#J_AllTree li').each(function () {
        var t = ($(this).find('a').text() || '').trim();
        if (t === CFG.CATEGORY_NAME) { hit = $(this); return false; }
      });
      return hit;
    }, 10000, 300, '目标分类节点');

    var $chk = $targetLi.find('.chk, [id$="_check"]').first();
    if (!$chk.length) throw new Error('目标节点无 checkbox');
    var cls = ($chk.attr('class') || '');
    if (cls.indexOf('checkbox_true') < 0) $chk.trigger('click');
    await sleep(800);

    var $dlg = $('.ue-dialog.focused').first();
    if (!$dlg.length) $dlg = $('#J_AllTree').closest('.ue-dialog');
    var $submit = $dlg.length ? $dlg.find('a.dialog-submit[data-role="submit"]').first() : $();
    if (!$submit.length) $submit = $('a.dialog-submit[data-role="submit"]').first();
    if (!$submit.length) $submit = $('span.btn-primary').filter(function () { return ($(this).text() || '').trim() === '确定'; }).first().closest('a,button');
    if ($submit.length) {
      try { $submit[0].click(); } catch (e) { }
      try { $submit.trigger('click'); } catch (e) { }
    }
    await sleep(700);
    log('步骤1 完成。', 'ok');
  }

  /* ================= 解析 docx（正文 + 图片） ================= */
  async function parseDocx() {
    log('▶ 解析 docx…', 'info');
    var arrayBuffer = await state.docxFile.arrayBuffer();

    var images = [];
    var idx = 0;
    await mammoth.convertToHtml(
      { arrayBuffer: arrayBuffer },
      {
        convertImage: mammoth.images.imgElement(function (image) {
          idx++;
          var myIdx = idx;
          return image.readAsBase64String().then(function (b64) {
            var mime = image.contentType || 'image/png';
            var ext = mime.indexOf('png') >= 0 ? 'png' : (mime.indexOf('gif') >= 0 ? 'gif' : 'jpg');
            images.push({ index: myIdx, name: 'img_' + myIdx + '.' + ext, base64: b64, mime: mime });
            return { src: '' };
          });
        })
      }
    );

    var result = await mammoth.convertToHtml({ arrayBuffer: arrayBuffer });
    var html = result.value;
    var counter = 0;
    html = html.replace(/<img[^>]*>/gi, function () {
      counter++;
      return '【图片' + counter + '】';
    });

    state.images = [];
    for (var i = 0; i < images.length; i++) {
      var bytes = atob(images[i].base64);
      var arr = new Uint8Array(bytes.length);
      for (var j = 0; j < bytes.length; j++) arr[j] = bytes.charCodeAt(j);
      var blob = new Blob([arr], { type: images[i].mime });
      var w = 0, h = 0;
      try {
        var bmp = await createImageBitmap(blob);
        w = bmp.width; h = bmp.height;
        bmp.close();
      } catch (e) { }
      state.images.push({ index: images[i].index, name: images[i].name, blob: blob, width: w, height: h });
    }

    state.parsedHtml = html;
    log('解析完成：正文 ' + html.length + ' 字符，图片 ' + state.images.length + ' 张。', 'ok');
  }

  /* ================= 步骤2-4 标题/来源/作者 ================= */
  async function fillTitleSourceAuthor() {
    if (!$) throw new Error('页面未加载 jQuery');
    var $titleInput = $('input[name="title"]');
    var title = ($titleInput.val() && $titleInput.val().trim())
      ? $titleInput.val().trim()
      : state.docxFile.name.replace(/\.docx$/i, '').trim().slice(0, CFG.TITLE_MAX_LEN);

    var rt = findInput(['input[name="title"]', 'input[data-role="title"]', '#title']);
    if (rt.$el) { simulateInput(rt.$el, title); log('步骤2 标题：「' + title + '」', 'ok'); }
    else log('⚠️ 未找到标题输入框，请手动填', 'warn');

    var $sel = $('select[name="origin"]').first();
    if ($sel.length) {
      var $opt = $sel.find('option').filter(function () { return ($(this).text() || '').trim() === CFG.SOURCE_TEXT; }).first();
      if ($opt.length) { $sel.val($opt.val()); $sel.trigger('change'); $sel.trigger('input'); log('步骤3 来源：「' + CFG.SOURCE_TEXT + '」', 'ok'); }
      else log('⚠️ 来源下拉无「' + CFG.SOURCE_TEXT + '」选项', 'warn');
    } else {
      var rs = findInput(['input[name="source"]', 'input[data-role="source"]', '#source']);
      if (rs.$el) { simulateInput(rs.$el, CFG.SOURCE_TEXT); log('步骤3 来源：「' + CFG.SOURCE_TEXT + '」', 'ok'); }
      else log('⚠️ 未找到来源字段', 'warn');
    }

    var m = title.match(/《([^》]+)》/);
    var author = m ? m[1] : '';
    if (author) {
      var ra = findInput(['input[name="author"]', 'input[data-role="author"]', '#author']);
      if (ra.$el) { simulateInput(ra.$el, author); log('步骤4 作者：「' + author + '」', 'ok'); }
      else log('⚠️ 未找到作者输入框', 'warn');
    } else {
      log('标题无《书名号》游戏名，作者留空', 'info');
    }
  }

  /* ================= 步骤5 正文写入 ================= */
  async function fillContent() {
    var ed = W.tinymce && W.tinymce.get('editor');
    if (!ed) throw new Error('tinymce.get("editor") 未就绪');
    var html = state.parsedHtml;
    var $titleInput = $('input[name="title"]');
    var title = ($titleInput.val() && $titleInput.val().trim())
      ? $titleInput.val().trim()
      : state.docxFile.name.replace(/\.docx$/i, '').trim().slice(0, CFG.TITLE_MAX_LEN);

    if (state.stripDup) {
      var tmp = document.createElement('div');
      tmp.innerHTML = html;
      var first = tmp.querySelector('p, h1, h2, h3');
      if (first) {
        var ft = (first.textContent || '').trim();
        var norm = function (s) { return s.replace(/[\s，。！？、：；""''（）《》]/g, '').slice(0, 50); };
        if (norm(ft) === norm(title)) { first.remove(); log('首句与标题重合已删除', 'info'); }
      }
      html = tmp.innerHTML;
    }
    ed.setContent(html);
    try { ed.fire('change'); } catch (e) { }
    log('步骤5 正文已写入（' + state.images.length + ' 个图片占位符）。', 'ok');
  }

  /* ================= 步骤6 智能填充元数据 ================= */
  async function smartFillMetadata() {
    if (!$) throw new Error('页面未加载 jQuery');
    var $btn = $('button[data-role="cmsaiGenTagAndGames"]').first();
    if (!$btn.length) {
      log('⚠️ 未找到「智能填充元数据」按钮，跳过该步', 'warn');
      return;
    }
    log('▶ 步骤6/6: 点击「智能填充元数据」…', 'info');
    $btn.trigger('click');

    var dlg = await waitFor(function () {
      var list = Array.prototype.slice.call(document.querySelectorAll('.ue-dialog'));
      for (var i = 0; i < list.length; i++) {
        if ((list[i].textContent || '').indexOf('识别到的游戏') >= 0) return list[i];
      }
      return null;
    }, 30000, 500, '智能填充提示弹窗');

    var content = dlg.querySelector('.dialog-content');
    log('弹窗已出现：' + ((content && content.textContent) || '').slice(0, 120) + '…', 'ok');

    var $dlg = $(dlg);
    var $submit = $dlg.find('a.dialog-submit[data-role="submit"]').first();
    if (!$submit.length) $submit = $('a.dialog-submit[data-role="submit"]').filter(':visible').first();
    if ($submit.length) {
      try { $submit[0].click(); } catch (e) { }
      try { $submit.trigger('click'); } catch (e) { }
      await sleep(600);
      log('已点击「确定」，智能填充完成。', 'ok');
    } else {
      log('⚠️ 未找到弹窗「确定」按钮，请手动点击', 'warn');
    }
  }

  /* ================= 发布模板选择：发布到 A-新闻终极页 ================= */
  async function selectPageTemplate() {
    if (!$) throw new Error('页面未加载 jQuery');
    var $sel = $('select#pageSelect_, select.pageId, select.push-articlepushtoose').first();
    if (!$sel.length) {
      log('⚠️ 未找到页面模板下拉框（#pageSelect_），跳过该步', 'warn');
      return;
    }
    var $opt = $sel.find('option').filter(function () {
      return ($(this).text() || '').trim() === 'A-新闻终极页';
    }).first();
    if (!$opt.length) {
      log('⚠️ 模板下拉无「A-新闻终极页」选项', 'warn');
      return;
    }
    $sel.val($opt.val());
    $sel.trigger('change');
    $sel.trigger('input');
    log('已选择发布模板：「A-新闻终极页」（' + $opt.val() + '）', 'ok');
  }

  /* ================= 步骤7 图片上传插入 ================= */
  async function compressBlob(blob) {
    if (!blob || blob.size <= CFG.IMG_SIZE_THRESHOLD) return blob;
    if (/gif/i.test(blob.type)) return blob;
    var bmp = await createImageBitmap(blob);
    var maxEdge = Math.max(bmp.width, bmp.height);
    if (maxEdge <= CFG.IMG_MAX_EDGE) { bmp.close(); return blob; }
    var scale = CFG.IMG_MAX_EDGE / maxEdge;
    var w = Math.round(bmp.width * scale), h = Math.round(bmp.height * scale);
    var canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    canvas.getContext('2d').drawImage(bmp, 0, 0, w, h);
    bmp.close();
    return new Promise(function (res) {
      canvas.toBlob(function (b) { log('压缩 ' + (blob.size / 1024).toFixed(0) + 'KB→' + (b.size / 1024).toFixed(0) + 'KB', 'info'); res(b); }, 'image/jpeg', CFG.IMG_JPEG_QUALITY);
    });
  }

  async function openUploadDialog() {
    if (!$) throw new Error('页面未加载 jQuery');
    var browseBtn = null;
    $('.mce-toolbar .mce-btn, .mce-toolbar button').each(function () {
      var aria = $(this).attr('aria-label') || '';
      var text = ($(this).text() || '').trim();
      if (aria === 'Browse' || aria === '浏览' || text.indexOf('浏览') >= 0 || text.indexOf('Browse') >= 0) { browseBtn = this; return false; }
    });
    if (!browseBtn) throw new Error('未找到编辑器「浏览/图片」按钮');
    realClick(browseBtn);
    var dlg = await waitFor(function () {
      var list = Array.prototype.slice.call(document.querySelectorAll('.ue-dialog'));
      for (var i = 0; i < list.length; i++) {
        if (isVisible(list[i]) && (list[i].textContent || '').indexOf('选择图片') >= 0) return list[i];
      }
      return null;
    }, 8000, 300, '选择图片弹窗');
    return dlg;
  }

  function feedFiles(dlg, files) {
    var input = dlg.querySelector('input[type="file"]');
    if (!input) return false;
    try {
      var dt = new DataTransfer();
      files.forEach(function (f) { dt.items.add(f); });
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
      input.dispatchEvent(new Event('input', { bubbles: true }));
      if ($) { try { $(input).trigger('change'); } catch (e) { } }
      return true;
    } catch (e) { return false; }
  }

  function uploadStats(dlg) {
    var files = Array.prototype.slice.call(dlg.querySelectorAll('.queue .file'));
    var done = 0, fail = 0, other = 0;
    files.forEach(function (f) {
      var p = f.querySelector('.progress');
      var cls = p ? (p.className || '') : '';
      if (cls.indexOf('fail') >= 0) fail++;
      else if (cls.indexOf('done') >= 0) done++;
      else other++;
    });
    return { done: done, fail: fail, other: other, total: files.length };
  }

  async function clickUploadAndWait(dlg) {
    if (!$) throw new Error('页面未加载 jQuery');
    var upBtn = null;
    $(dlg).find('button, a').each(function () {
      if (($(this).text() || '').replace(/\s+/g, '') === '确定上传') { upBtn = this; return false; }
    });
    if (!upBtn) throw new Error('未找到「确定上传」按钮');
    log('点击「确定上传」（仅一次）…', '');
    realClick(upBtn);

    var hasFiles = await waitFor(function () {
      return dlg.querySelectorAll('.queue .file').length > 0 ? true : null;
    }, 15000, 500, '上传队列');
    if (!hasFiles) { log('队列无文件，请手动添加后重试', 'warn'); return 'no-files'; }

    var start = Date.now();
    while (Date.now() - start < CFG.UPLOAD_TIMEOUT) {
      await sleep(1000);
      var st = uploadStats(dlg);
      if (st.fail > 0) { log('⚠️ ' + st.fail + ' 张失败（成功 ' + st.done + '/' + st.total + '），停止（避免重复图片）', 'err'); return 'failure'; }
      if (st.total > 0 && st.other === 0 && st.fail === 0) { log('✅ ' + st.done + ' 张全部上传成功', 'ok'); return 'all-done'; }
    }
    log('上传等待超时', 'err');
    return 'timeout';
  }

  async function clickInsert(dlg) {
    if (!$) throw new Error('页面未加载 jQuery');
    var insBtn = null;
    $(dlg).find('button:not([disabled]), a').each(function () {
      if (($(this).text() || '').replace(/\s+/g, '') === '确定插入') { insBtn = this; return false; }
    });
    if (!insBtn) { log('未找到「确定插入」，跳过', 'warn'); return false; }
    realClick(insBtn);
    await sleep(800);
    return true;
  }

  function closeDialog(dlg) {
    var closeBtn = dlg.querySelector('.dialog-close[data-role="close"], [data-role="close"]');
    if (closeBtn) { realClick(closeBtn); }
  }

  // 读取侧栏图片：返回 [{original, thumb, name}]，original=原图URL，thumb=带缩略图后缀URL
  async function readSidebarUrls() {
    var tab = document.querySelector('.mce-sidebar a[href="#sidebar-image"]');
    if (tab) clickEl(tab);
    var items = await waitFor(function () {
      var list = Array.prototype.slice.call(document.querySelectorAll('#sidebar-image li[data-role="item"]'));
      return list.length ? list : null;
    }, 8000, 300, '侧栏图片');
    var urls = [], seen = {};
    items.forEach(function (li) {
      var img = li.querySelector('.thumb img');
      if (!img) return;
      var raw = img.getAttribute('src') || img.currentSrc || '';
      if (!raw) return;
      var original = raw.split('!')[0];
      var thumb = raw;
      var key = (original.split('/').pop() || original).split('?')[0].split('#')[0];
      if (seen[key]) return;
      seen[key] = true;
      var p = function (u) { return u.replace(/^https?:\/\//, '//'); };
      urls.push({ original: p(original), thumb: p(thumb), name: key });
    });
    log('侧栏读取 ' + urls.length + ' 张（去重后）。', 'ok');
    return urls;
  }

  // 替换正文【图片N】占位符为居中图片（对齐 CMS browse 插件格式）
  function replacePlaceholders(urls) {
    var ed = W.tinymce && W.tinymce.get('editor');
    if (!ed) return 0;
    var html = ed.getContent();
    var replaced = 0;
    html = html.replace(/【图片(\d+)】/g, function (m, idx) {
      var i = parseInt(idx, 10) - 1;
      var item = urls[i];
      if (!item) return m;
      var info = state.images[i] || {};
      var w = info.width || 0;
      var h = info.height || 0;
      var dispW = (w > 540) ? 540 : (w || 540);
      var alt = (info.name || item.name || '').replace(/[&<>"']/g, '');
      var imgTag = '<img src="' + item.thumb + '" data-imgwidth="' + w + '" data-imgheight="' + h + '" width="' + dispW + '" alt="' + alt + '">';
      replaced++;
      return '<p class="p-image" style="text-align: center;"><a href="http://newgame.17173.com/viewpic.htm?url=' + item.original + '" target="_blank">' + imgTag + '</a></p>';
    });
    ed.setContent(html);
    try { ed.fire('change'); } catch (e) { }
    log('✅ 已替换 ' + replaced + ' 个占位符。', 'ok');
    return replaced;
  }

  async function uploadAndInsertImages() {
    if (!state.images.length) { log('docx 无图片，跳过上传。', 'warn'); return; }
    var files = [];
    for (var i = 0; i < state.images.length; i++) {
      var finalBlob = state.compress ? await compressBlob(state.images[i].blob) : state.images[i].blob;
      files.push(new File([finalBlob], state.images[i].name, { type: finalBlob.type || 'image/jpeg' }));
    }
    var dlg = await openUploadDialog();
    await sleep(600);
    if (!feedFiles(dlg, files)) { log('⚠️ 自动注入未成功，请手动点「添加图片」选择文件后点「确定上传」。', 'warn'); return; }
    await sleep(1500);
    var result = await clickUploadAndWait(dlg);
    if (result !== 'all-done') { log('上传未全部成功，请手动处理后点「读取侧栏图片并插入」。', 'err'); return; }
    await clickInsert(dlg);
    closeDialog(dlg);
    var urls = await readSidebarUrls();
    replacePlaceholders(urls);
  }

  /* ================= 主流程（点「开始填充」触发） ================= */
  async function runFullPipeline() {
    if (state.running) { log('已有任务进行中', 'warn'); return; }
    if (!state.docxFile) { log('请先选择 .docx 文件', 'warn'); return; }
    state.running = true;
    try {
      log('========== 开始 ==========', 'info');
      await parseDocx();
      await selectCategory();
      await fillTitleSourceAuthor();
      await fillContent();
      await smartFillMetadata();
      await selectPageTemplate();
      if (state.autoUpload && state.images.length) {
        await uploadAndInsertImages();
      } else {
        log('跳过图片上传（未勾选或无图片），可用「读取侧栏图片并插入」兜底', 'warn');
      }
      log('========== ✅ 全部完成，请核对后发布 ==========', 'ok');
    } catch (e) {
      log('❌ 流程中断: ' + e.message, 'err');
      console.error(e);
    } finally {
      state.running = false;
    }
  }

  /* ================= 用文内标题 ================= */
  async function useDocTitle() {
    if (state.running) { log('已有任务进行中', 'warn'); return; }
    if (!state.docxFile) { log('请先选择 .docx 文件', 'warn'); return; }
    try {
      log('▶ 识别文内标题（加粗/大字优先）…', 'info');
      var title = await extractTitleFromDocx(state.docxFile);
      if (!title) { log('未识别到文内标题，请改用「开始填充」。', 'warn'); return; }
      var rt = findInput(['input[name="title"]', 'input[data-role="title"]', '#title']);
      if (rt.$el) { simulateInput(rt.$el, title); log('已用文内标题：「' + title + '」', 'ok'); }
      else log('⚠️ 未找到标题输入框，标题识别为：「' + title + '」', 'warn');
      await runFullPipeline();
    } catch (e) {
      log('❌ 文内标题流程出错: ' + e.message, 'err');
      console.error(e);
    }
  }

  async function reUploadImages() {
    if (!state.images.length) { log('无待上传图片，请先选择 docx', 'warn'); return; }
    await uploadAndInsertImages();
  }

  async function insertFromSidebar() {
    try {
      var urls = await readSidebarUrls();
      replacePlaceholders(urls);
    } catch (e) { log('兜底插入失败: ' + e.message, 'err'); }
  }

  function clearAll() {
    state.docxFile = null; state.parsedHtml = ''; state.images = []; state.docTitle = '';
    var f = document.querySelector('#__cms_file');
    if (f) f.value = '';
    if (logBox) logBox.innerHTML = '';
  }

  /* ================= 面板 ================= */
  function buildPanel() {
    var root = document.createElement('div');
    root.id = '__cms_panel';
    root.style.cssText = 'position:fixed;right:14px;top:14px;z-index:2147483647;width:350px;background:#fff;border:1px solid #bdc3c7;border-radius:8px;box-shadow:0 6px 20px rgba(0,0,0,.3);font-family:Microsoft YaHei,sans-serif;font-size:13px;color:#333;';
    root.innerHTML =
      '<div style="padding:8px 12px;background:#2c3e50;color:#fff;border-radius:8px 8px 0 0;display:flex;justify-content:space-between;align-items:center;"><b>17173 厂商稿发布助手</b><span id="__cms_toggle" style="cursor:pointer;font-size:14px;">▾</span></div>' +
      '<div id="__cms_body" style="padding:10px 12px;">' +
      '<div style="margin-bottom:8px;"><input type="file" id="__cms_file" accept=".docx" style="width:100%;"></div>' +
      '<div style="margin-bottom:8px;">' +
      '<label style="display:block;"><input type="checkbox" id="__cms_opt_upload" checked> 自动上传并插入图片</label>' +
      '<label style="display:block;"><input type="checkbox" id="__cms_opt_compress" checked> 压缩大图(&gt;1.5MB)</label>' +
      '<label style="display:block;"><input type="checkbox" id="__cms_opt_strip" checked> 首句=标题时删除</label>' +
      '</div>' +
      '<div style="margin-bottom:8px;">' +
      '<button id="__cms_btn_doctitle" style="background:#e67e22;color:#fff;border:none;border-radius:4px;padding:7px 10px;cursor:pointer;">用文内标题</button>' +
      '<button id="__cms_btn_start" style="background:#27ae60;color:#fff;border:none;border-radius:4px;padding:7px 14px;cursor:pointer;font-weight:bold;">开始填充</button>' +
      '</div>' +
      '<div style="margin-bottom:8px;">' +
      '<button id="__cms_btn_reupload" style="background:#16a085;color:#fff;border:none;border-radius:4px;padding:7px 10px;cursor:pointer;">重新上传图片</button>' +
      '<button id="__cms_btn_sidebar" style="background:#8e44ad;color:#fff;border:none;border-radius:4px;padding:7px 10px;cursor:pointer;">读取侧栏插入</button>' +
      '<button id="__cms_btn_clear" style="background:#95a5a6;color:#fff;border:none;border-radius:4px;padding:7px 10px;cursor:pointer;">清空</button>' +
      '</div>' +
      '<div id="__cms_log" style="background:#f8f8f8;border:1px solid #eee;border-radius:4px;padding:6px;height:240px;overflow:auto;font-size:12px;"></div>' +
      '</div>';
    document.body.appendChild(root);
    logBox = root.querySelector('#__cms_log');

    root.querySelector('#__cms_toggle').addEventListener('click', function () {
      var body = root.querySelector('#__cms_body');
      var hidden = body.style.display === 'none';
      body.style.display = hidden ? '' : 'none';
      this.textContent = hidden ? '▾' : '▸';
    });
    root.querySelector('#__cms_opt_upload').addEventListener('change', function () { state.autoUpload = this.checked; });
    root.querySelector('#__cms_opt_compress').addEventListener('change', function () { state.compress = this.checked; });
    root.querySelector('#__cms_opt_strip').addEventListener('change', function () { state.stripDup = this.checked; });
    root.querySelector('#__cms_file').addEventListener('change', function () {
      var f = this.files && this.files[0];
      if (!f) return;
      state.docxFile = f;
      log('已选择: ' + f.name + '。点「用文内标题」识别文内标题，或点「开始填充」。', 'info');
    });
    root.querySelector('#__cms_btn_doctitle').addEventListener('click', useDocTitle);
    root.querySelector('#__cms_btn_start').addEventListener('click', runFullPipeline);
    root.querySelector('#__cms_btn_reupload').addEventListener('click', reUploadImages);
    root.querySelector('#__cms_btn_sidebar').addEventListener('click', insertFromSidebar);
    root.querySelector('#__cms_btn_clear').addEventListener('click', clearAll);
    log('面板就绪。选择 .docx 后点「开始填充」或「用文内标题」。', 'ok');
  }

  /* ================= 启动 ================= */
  if (window.location.hostname.indexOf('17173') < 0) return;
  if (document.getElementById('__cms_panel')) return;
  function start() {
    waitFor(function () {
      return (W.tinymce && W.tinymce.get('editor')) || (window.$ && $('button[data-role="selectCategory"]').length) ? true : null;
    }, 30000, 500, '页面就绪')
      .then(function () { buildPanel(); })
      .catch(function () { buildPanel(); });
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(start, 500);
  else window.addEventListener('DOMContentLoaded', function () { setTimeout(start, 500); });
})();
